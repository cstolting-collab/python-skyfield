import hashlib
import json
import sys
import warnings
from pathlib import Path

import numpy as np
import pandas as pd
import jplephem
from skyfield.api import Loader, Star, wgs84
from skyfield.data.hipparcos import load_dataframe
from skyfield.errors import EphemerisRangeError

root = Path(__file__).parent
mode = sys.argv[1]
catalog = root / 'hip_main_full.dat'
with catalog.open('rb') as f:
    df = load_dataframe(f)
good = df['ra_degrees'].notnull() & df['dec_degrees'].notnull()
load = Loader(str(root / 'python-skyfield' / 'ci'), verbose=False)
ts = load.timescale()
t = ts.utc(2026, 5, 19, 3)
eph = load('de421.bsp')
results = []
try:
    for name, observer in [('earth', eph['earth']),
                           ('surface', eph['earth'] + wgs84.latlon(35, -111))]:
        observer = observer.at(t)
        astrometric = observer.observe(Star.from_dataframe(df))
        if mode == 'baseline':
            with warnings.catch_warnings(record=True) as caught:
                warnings.simplefilter('always')
                try:
                    astrometric.apparent()
                except EphemerisRangeError:
                    pass
                else:
                    raise AssertionError('Expected baseline to fail')
            assert any('invalid value encountered in cast' in str(w.message)
                       for w in caught)
            expected = observer.observe(Star.from_dataframe(df[good])).apparent()
            np.save(root / ('baseline-' + name + '.npy'), expected.xyz.au)
            results.append({'observer': name, 'full_catalog': 'EphemerisRangeError',
                            'valid_positions_recorded': int(good.sum())})
        else:
            with warnings.catch_warnings():
                warnings.simplefilter('error')
                with np.errstate(all='raise'):
                    apparent = astrometric.apparent()
                    xyz = apparent.xyz.au
                    assert xyz.shape == (3, len(df))
                    assert np.isnan(xyz[:, ~good]).all()
                    assert np.isfinite(xyz[:, good]).all()
                    expected = np.load(root / ('baseline-' + name + '.npy'))
                    assert xyz[:, good].tobytes() == expected.tobytes()
                    for hip in df.index[~good]:
                        result = observer.observe(Star.from_dataframe(df.loc[hip])).apparent()
                        assert np.isnan(result.xyz.au).all()
                    if name == 'surface':
                        alt, az, distance = apparent.altaz()
                        assert np.isnan(alt.degrees[~good]).all()
                        assert np.isnan(az.degrees[~good]).all()
                        assert np.isfinite(alt.degrees[good]).all()
                        assert np.isfinite(az.degrees[good]).all()
            results.append({'observer': name, 'full_catalog': 'PASS',
                            'unchanged_valid_positions': int(good.sum()),
                            'nan_rows_preserved': int((~good).sum()),
                            'individual_nan_stars_checked': int((~good).sum())})
finally:
    eph.close()
report = dict(mode=mode, python=sys.version.split()[0], numpy=np.__version__,
              pandas=pd.__version__, jplephem=jplephem.__version__,
              catalog_url='https://vizier.cfa.harvard.edu/ftp/cats/I/239/hip_main.dat',
              catalog_sha256=hashlib.sha256(catalog.read_bytes()).hexdigest(),
              total_rows=len(df), results=results)
print(json.dumps(report, indent=2))
(root / ('catalog-' + mode + '.json')).write_text(json.dumps(report, indent=2) + '\n')
