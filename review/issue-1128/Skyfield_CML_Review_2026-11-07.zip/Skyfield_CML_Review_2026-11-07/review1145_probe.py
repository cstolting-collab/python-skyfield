import inspect
import json
import sys
import warnings
from pathlib import Path

import numpy as np
from skyfield import almanac, api

root = Path(__file__).parent
mode = sys.argv[1]
load = api.Loader(str(root / 'skyfield-pr1145' / 'ci'), verbose=False)
ts = load.timescale()
eph = load('de421.bsp')
report = dict(mode=mode, numpy=np.__version__, cases=[], boundary=[])
reference_path = root / 'pr1145-probe-head.json'
reference = json.loads(reference_path.read_text()) if mode != 'head' else None
boundary_inputs = {} if reference is None else {
    (r['lat'], r['body'], r['name'], r['offset_us']): r
    for r in reference['boundary']
}

source, first = inspect.getsourcelines(almanac._find)
rate_line = first + next(i for i, line in enumerate(source)
                         if 'ha_per_day = ha_diff' in line
                         or 'np.divide(ha_diff, t_diff' in line)
trace_data = []
def trace(frame, event, arg):
    if frame.f_code is almanac._find.__code__ and event == 'line' and frame.f_lineno == rate_line:
        local = frame.f_locals
        stuck = local.get('stuck', local['t_diff'] == 0.0)
        trace_data.append(dict(iteration=int(local['i']),
                               stuck=int(np.count_nonzero(stuck)),
                               zero_ha=int(np.count_nonzero(local['ha_diff'] == 0.0))))
    return trace

def find(observer, target, name, start, end, horizon=None):
    if name == 'transit':
        t = almanac.find_transits(observer, target, start, end)
        return t, np.ones(t.shape, dtype=bool)
    fn = almanac.find_risings if name == 'rise' else almanac.find_settings
    return fn(observer, target, start, end, horizon_degrees=horizon)

def call(observer, target, name, start, end, horizon=None, traced=False):
    trace_data[:] = []
    try:
        with warnings.catch_warnings():
            warnings.simplefilter('error', RuntimeWarning)
            if traced:
                sys.settrace(trace)
            t, y = find(observer, target, name, start, end, horizon)
        assert np.isfinite(t.tt).all()
        return dict(whole=t.whole.tolist(), fraction=t.tt_fraction.tolist(),
                    flags=y.tolist(), trace=list(trace_data))
    except Exception as e:
        return dict(error=type(e).__name__ + ': ' + str(e), trace=list(trace_data))
    finally:
        sys.settrace(None)

try:
    for lat in (-60, -30, 0, 19.8256, 45, 66, 70, 80):
        observer = eph['earth'] + api.wgs84.latlon(lat, -155.4761)
        for month, day in ((3, 20), (6, 21), (9, 23), (12, 21)):
            for body in ('sun', 'moon'):
                for name in ('rise', 'set', 'transit'):
                    start = ts.utc(2026, month, day)
                    r = call(observer, eph[body], name, start, start + 2)
                    report['cases'].append(dict(lat=lat, month=month, body=body, name=name, result=r))

    for lat in (0, 19.8256, 66, 70):
        observer = eph['earth'] + api.wgs84.latlon(lat, -155.4761, 4139)
        for body in ('sun', 'moon'):
            for name in ('rise', 'set', 'transit'):
                start = ts.utc(2026, 8, 8)
                t, y = find(observer, eph[body], name, start, start + 2, 0.0)
                real = t[y]
                if len(real) == 0:
                    continue
                event = real[0]
                for offset_us in (-1000, -100, -40, -20, -10, -1, 0, 1, 10, 20, 40, 100, 1000):
                    start = ts.tt_jd(event.whole, event.tt_fraction + offset_us / 86400e6)
                    if boundary_inputs:
                        saved = boundary_inputs[lat, body, name, offset_us]
                        start = ts.tt_jd(saved['start_whole'], saved['start_fraction'])
                    r = call(observer, eph[body], name, start, start + 1.05, 0.0, True)
                    report['boundary'].append(dict(lat=lat, body=body, name=name, offset_us=offset_us,
                        start_whole=float(start.whole), start_fraction=float(start.tt_fraction), result=r))

    # Make the supplied start instant itself the horizon-crossing by
    # choosing the horizon from its apparent altitude.
    report['exact'] = []
    for lat in (0, 19.8256, 66, 70):
        observer = eph['earth'] + api.wgs84.latlon(lat, -155.4761, 4139)
        for hour in (3, 5, 10, 16, 20):
            for body in ('sun', 'moon'):
                start = ts.utc(2026, 8, 8, hour)
                start = ts.tt_jd(start.tt)
                almanac._fastify(start)
                altitude = observer.at(start).observe(eph[body]).apparent(()).altaz()[0].degrees
                for name in ('rise', 'set'):
                    r = call(observer, eph[body], name, start, start + 1.05, float(altitude), True)
                    report['exact'].append(dict(lat=lat, body=body, hour=hour, name=name,
                        start=float(start.tt), horizon=float(altitude), result=r))
finally:
    eph.close()

(root / ('pr1145-probe-' + mode + '.json')).write_text(json.dumps(report, indent=2) + '\n')
for key in ('cases', 'boundary', 'exact'):
    records = report[key]
    errors = [r for r in records if 'error' in r['result']]
    guards = [r for r in records if any(t['stuck'] for t in r['result']['trace'])]
    print(key, 'total=',len(records), 'errors=',len(errors), 'stuck_cases=',len(guards), flush=True)
    for item in errors[:3]:
        print(json.dumps(item), flush=True)
    if guards:
        print('first_stuck', json.dumps(guards[0]), flush=True)
