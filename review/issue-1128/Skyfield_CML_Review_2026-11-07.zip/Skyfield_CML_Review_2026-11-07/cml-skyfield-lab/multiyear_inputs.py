"""A second, reproducible holdout spanning 1905-2045 and polar latitudes."""
import json
from pathlib import Path
import numpy as np
from skyfield import api

ts = api.load.timescale()
rng = np.random.default_rng(780231)
first, last = ts.utc(1905, 1, 1), ts.utc(2045, 1, 1)
records = []
for i in range(512):
    start = first + float(rng.uniform(0, last - first))
    end = start + float(10.0 ** rng.uniform(-2, np.log10(8)))
    lat = float(rng.uniform(-89.99, 89.99) if i % 2 else
                rng.choice([-1, 1]) * rng.uniform(80, 89.99))
    records.append(dict(id=f'multiyear-{i}', group='holdout', lat=lat,
        lon=float(rng.uniform(-180, 180)), height=float(rng.uniform(-400, 8849)),
        body=str(rng.choice(['sun', 'moon', 'mercury', 'venus', 'mars',
            'jupiter barycenter', 'saturn barycenter', 'neptune barycenter'])),
        kind=str(rng.choice(['rise', 'set', 'transit'])),
        start=[float(start.whole), float(start.tt_fraction)],
        end=[float(end.whole), float(end.tt_fraction)],
        horizon=[None, -18.0, -6.0, 0.0, 30.0][int(rng.integers(5))]))
Path(__file__).with_name('multiyear-inputs.json').write_text(
    json.dumps(records, indent=2)+'\n')
