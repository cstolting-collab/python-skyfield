import assert from 'node:assert/strict';
import { readFileSync, writeFileSync } from 'node:fs';
import { performance } from 'node:perf_hooks';
import { StateGovernance } from 'cml-reference-compiler/runtime';

const read = path => JSON.parse(readFileSync(new URL(path, import.meta.url)));
const rules = read('decisions-extra-after.json').rules;
const states = read('observations-extra-after.json').states;
const good = structuredClone(states.find(s => s.inputs.group === 'tiny'));
const cml = new StateGovernance();
const initial = cml.evaluateTransition({candidateState: good, invariants: rules,
  provenanceRecord: {id: 'accepted', stateKey: 'checks', value: good.checks,
    source: 'positive control', status: 'validated'}});
assert.equal(initial.accepted, true);
let canonical = initial.state;
cml.commitProvenance(initial.provenanceRecord);
const before = JSON.stringify(canonical);
const controls = [];
const mutations = [
  ['exception', s => s.status = 'error'],
  ...['finite', 'paired', 'ordered', 'within_window', 'complete', 'crossing_bracketed']
    .map(key => [key, s => s.checks[key] = false]),
  ...['finite', 'complete', 'crossing_bracketed']
    .map(key => [`missing_${key}`, s => delete s.checks[key]]),
  ['unknown_contract', s => s.contract = 'unsupported'],
  ['raw_nan', s => s.offsets_seconds = [NaN]],
];
for (const [name, mutate] of mutations) {
  const candidate = structuredClone(good);
  mutate(candidate);
  let rejected = false;
  let reason;
  try {
    const result = cml.evaluateTransition({previousState: canonical,
      candidateState: candidate, invariants: rules});
    rejected = !result.accepted;
    reason = result.validation.violations.map(v => v.id);
    if (result.accepted) canonical = result.state;
  } catch (error) {
    assert.equal(name, 'raw_nan');
    rejected = true;
    reason = error.message;
  }
  assert.equal(rejected, true, name);
  assert.equal(JSON.stringify(canonical), before, name);
  assert.equal(cml.provenance.size(), 1, name);
  controls.push({name, rejected, reason, canonicalUnchanged: true,
    rejectedProvenanceAppended: false});
}
// Explicit limit: the runtime evaluates supplied predicates. A dishonest or
// broken arithmetic adapter can label bad metrics as good; CML cannot infer
// astronomy from those labels. This control prevents overstating the result.
const dishonest = structuredClone(good);
dishonest.offsets_seconds = [-100];
const trustedAdapterLimit = cml.evaluateTransition({candidateState: dishonest,
  invariants: rules}).accepted;
assert.equal(trustedAdapterLimit, true);

// Ordinary host logic with these same predicates must agree with CML.
const hostAccepts = s => s.status === 'ok' &&
  ['finite', 'paired', 'ordered', 'within_window'].every(k => s.checks[k] === true) &&
  (s.inputs.group !== 'tiny' || s.checks.complete === true) &&
  s.checks.crossing_bracketed === true;
let equivalent = 0;
const started = performance.now();
for (const s of [...read('observations-extra-before.json').states, ...states]) {
  const result = cml.evaluateTransition({candidateState: s, invariants: rules});
  assert.equal(result.accepted, hostAccepts(s));
  equivalent++;
}
const elapsed = performance.now() - started;
const report = {positiveControlAccepted: true, negativeControlsRejected: controls.length,
  controls, trustedAdapterLimit: 'Bad metrics with dishonest passing predicates are accepted; the arithmetic adapter remains trusted.',
  samePredicatesAgreeWithPlainHostLogic: equivalent,
  evaluationBenchmark: {cases: equivalent, elapsedMs: elapsed,
    averageMs: elapsed / equivalent, includesPlainHostComparison: true,
    scope: 'Single local unoptimized run; not an end-to-end performance promise.'}};
writeFileSync(new URL('control-results.json', import.meta.url), JSON.stringify(report,null,2)+'\n');
console.log(JSON.stringify({...report, controls: undefined}));
