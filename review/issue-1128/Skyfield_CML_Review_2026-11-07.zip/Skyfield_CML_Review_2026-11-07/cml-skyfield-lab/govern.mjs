// Real CML runtime public API, unchanged and pinned in cml-provenance.json.
import { readFileSync, writeFileSync } from 'node:fs';
import { createHash } from 'node:crypto';
import { StateGovernance } from 'cml-reference-compiler/runtime';

export const rules = [
  { id: 'contract', assert: { path: 'contract', op: 'oneOf',
    values: ['replay-v1', 'exploration-v1'] } },
  { id: 'completed', assert: { path: 'status', op: 'equals', value: 'ok' } },
  ...['finite', 'paired', 'ordered', 'within_window'].map(key => ({
    id: key, when: { path: 'status', op: 'equals', value: 'ok' },
    assert: { path: `checks.${key}`, op: 'equals', value: true },
  })),
  { id: 'complete', when: { path: 'inputs.group', op: 'equals', value: 'tiny' },
    assert: { path: 'checks.complete', op: 'equals', value: true } },
  { id: 'crossing_bracketed', when: { path: 'contract', op: 'equals', value: 'exploration-v1' },
    assert: { path: 'checks.crossing_bracketed', op: 'equals', value: true } },
];
const mode = process.argv[2];
const bytes = readFileSync(new URL(`observations-${mode}.json`, import.meta.url));
const input = JSON.parse(bytes);
const sha256 = createHash('sha256').update(bytes).digest('hex');
const governance = new StateGovernance();
const decisions = [];
const canonical = new Map();
for (const candidateState of input.states) {
  const outcome = governance.evaluateTransition({
    candidateState, invariants: rules,
    provenanceRecord: {
      id: `${mode}:${candidateState.id}`, stateKey: 'checks',
      value: candidateState.checks, status: 'validated',
      source: { type: 'host_observation', sha256 },
      evidence: { cmlCommit: '8331c3b1ac6450b12e8a944bd29c629e0f21ae4d' },
    },
  });
  if (outcome.accepted) {
    // The host commits to its in-memory accepted-state map first, then
    // records evidence. This is a lab, not a durable database transaction.
    canonical.set(candidateState.id, outcome.state);
    governance.commitProvenance(outcome.provenanceRecord);
  }
  decisions.push({ id: candidateState.id, accepted: outcome.accepted,
    checked: outcome.validation.checked,
    violations: outcome.validation.violations.map(v => v.id) });
}
const counts = {};
for (const d of decisions) for (const key of d.violations) counts[key] = (counts[key] ?? 0) + 1;
const report = { mode, engine: 'CML StateGovernance via public /runtime export',
  sha256, inputStates: decisions.length, accepted: canonical.size,
  rejected: decisions.length - canonical.size, violationCounts: counts,
  provenanceRecords: governance.provenance.size(), rules, decisions };
writeFileSync(new URL(`decisions-${mode}.json`, import.meta.url), JSON.stringify(report, null, 2)+'\n');
console.log(JSON.stringify({ ...report, rules: undefined, decisions: undefined }));
