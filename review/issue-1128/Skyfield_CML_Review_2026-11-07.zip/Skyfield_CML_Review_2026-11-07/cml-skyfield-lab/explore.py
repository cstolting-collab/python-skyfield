"""Replay new boundary cases and seeded holdout searches through Skyfield.

Inputs are created once and reused across checkouts. Numerical predicates are
host observations; the separate govern.mjs invokes the genuine CML runtime.
"""
import json
import sys
import warnings
from pathlib import Path
import numpy as np
from skyfield import api, almanac

HERE = Path(__file__).resolve().parent
ROOT = HERE.parent
load = api.Loader(str(ROOT / 'skyfield-pr1145/ci'), verbose=False)
ts = load.timescale()
eph = load('de421.bsp')


def find(observer, target, kind, start, end, horizon):
    if kind == 'transit':
        t = almanac.find_transits(observer, target, start, end)
        return t, np.ones(t.shape, dtype=bool)
    f = almanac.find_risings if kind == 'rise' else almanac.find_settings
    return f(observer, target, start, end, horizon_degrees=horizon)


def create_inputs():
    inputs = []
    ref = json.loads((ROOT / 'pr1145-probe-head.json').read_text())['boundary']
    windows = [(-1000, 1000), (-20, 20), (-10, 10), (10, 1000),
               (-1000, -10), (1000, 1000)]
    for r in ref:
        if r['offset_us'] != 0:
            continue
        event = ts.tt_jd(r['start_whole'], r['start_fraction'])
        for low, high in windows:
            start = event + low / 86400e6
            end = event + high / 86400e6
            inputs.append(dict(id=f'tiny-{len(inputs)}', lat=r['lat'],
                lon=-155.4761, height=4139, body=r['body'], kind=r['name'],
                start=[float(start.whole), float(start.tt_fraction)],
                end=[float(end.whole), float(end.tt_fraction)], horizon=0.0,
                expected_count=int(low < 0 < high), group='tiny'))
    # This seed is fixed before inspecting the outcomes. Half of the searches
    # use very high latitudes, where horizon crossings can become tangential.
    rng = np.random.default_rng(20261107)
    for i in range(256):
        lat = float(rng.uniform(-65, 65) if i % 2 else
                    rng.choice([-1, 1]) * rng.uniform(65, 89.5))
        lon = float(rng.uniform(-180, 180))
        start = ts.utc(2026, 1, 1) + float(rng.uniform(0, 364))
        end = start + float(rng.uniform(0.1, 4))
        inputs.append(dict(id=f'holdout-{i}', lat=lat, lon=lon,
            height=float(rng.uniform(0, 4500)),
            body=str(rng.choice(['sun', 'moon', 'mercury', 'venus', 'mars',
                                 'jupiter barycenter'])),
            kind=str(rng.choice(['rise', 'set', 'transit'])),
            start=[float(start.whole), float(start.tt_fraction)],
            end=[float(end.whole), float(end.tt_fraction)],
            horizon=[None, -18.0, -6.0, 0.0][int(rng.integers(4))],
            group='holdout'))
    (HERE / 'exploration-inputs.json').write_text(json.dumps(inputs, indent=2)+'\n')


def observe(r):
    observer = eph['earth'] + api.wgs84.latlon(r['lat'], r['lon'], r['height'])
    target = eph[r['body']]
    start, end = (ts.tt_jd(*r[k]) for k in ('start', 'end'))
    state = dict(id=r['id'], contract='exploration-v1', inputs=r, status='ok', checks={})
    try:
        with warnings.catch_warnings():
            warnings.simplefilter('error', RuntimeWarning)
            t, y = find(observer, target, r['kind'], start, end, r['horizon'])
        offsets = (t - start) * 86400.0
        duration = float((end - start) * 86400.0)
        state.update(offsets_seconds=offsets.tolist(), end_offset_seconds=duration,
            evidence=dict(whole=t.whole.tolist(), fraction=t.tt_fraction.tolist(),
                          flags=y.tolist()))
        state['checks'] = dict(finite=bool(np.isfinite(offsets).all()),
            paired=len(t) == len(y), ordered=bool((np.diff(offsets) > 0).all()),
            within_window=bool(((offsets >= -1e-6)
                               & (offsets <= duration + 1e-6)).all()))
        if 'expected_count' in r:
            state['checks']['complete'] = int(y.sum()) == r['expected_count']
        # Domain check at +/-60 seconds: only true crossings must bracket
        # the horizon with the requested direction. False high-latitude
        # placeholders are intentionally excluded from this rule.
        true_t = t[y]
        def residual(delta):
            at = true_t + delta / 86400.0
            almanac._fastify(at)
            app = observer.at(at).observe(target).apparent(())
            if r['kind'] == 'transit':
                ha = app.hadec()[0].radians
                return (ha + np.pi) % (2*np.pi) - np.pi
            alt, _, distance = app.altaz()
            horizon = (almanac.build_horizon_function(target)(distance)
                       if r['horizon'] is None else np.deg2rad(r['horizon']))
            return alt.radians - horizon
        lo, hi = residual(-60), residual(60)
        if r['kind'] == 'set':
            direction = (lo > 0) & (hi < 0)
        else:
            direction = (lo < 0) & (hi > 0)
        state['checks']['crossing_bracketed'] = bool(direction.all())
        state['crossing_residuals_radians'] = dict(
            before=lo.tolist(), at=residual(0).tolist(), after=hi.tolist())
    except Exception as e:
        state.update(status='error', evidence=dict(error=type(e).__name__+': '+str(e)))
    return state


try:
    mode = sys.argv[1]
    if mode == 'inputs':
        create_inputs()
    else:
        dataset = sys.argv[2] if len(sys.argv) > 2 else 'exploration-inputs.json'
        inputs = json.loads((HERE / dataset).read_text())
        states = [observe(r) for r in inputs]
        (HERE / f'observations-{mode}.json').write_text(
            json.dumps(dict(mode=mode, numpy=np.__version__, states=states),
                       indent=2, allow_nan=False)+'\n')
        print(mode, len(states), 'searches', flush=True)
finally:
    eph.close()
