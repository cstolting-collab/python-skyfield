"""Cross-check returned roots using bisection, not the almanac's iteration.

This uses the SAME ephemeris and apparent-position model. It is an independent
root-finding check, not independent astronomical ground truth.
"""
import json
from pathlib import Path
import numpy as np
from skyfield import api, almanac

HERE = Path(__file__).resolve().parent
load = api.Loader(str(HERE.parent / 'skyfield-pr1145/ci'), verbose=False)
ts = load.timescale()
eph = load('de421.bsp')
observations = []
for mode in ('extra-after', 'multiyear-after'):
    batch = json.loads((HERE / f'observations-{mode}.json').read_text())['states']
    for s in batch:
        s['_dataset'] = mode
    observations.extend(batch)
records = []
per_dataset = {}
try:
    for s in observations:
        if s['inputs']['group'] != 'holdout' or s['status'] != 'ok':
            continue
        if per_dataset.get(s['_dataset'], 0) == 48:
            continue
        data = s['evidence']
        valid = np.array(data['flags'], dtype=bool)
        if not valid.any():
            continue
        r = s['inputs']
        t = ts.tt_jd(np.array(data['whole'])[valid][:1],
                     np.array(data['fraction'])[valid][:1])
        observer = eph['earth'] + api.wgs84.latlon(r['lat'], r['lon'], r['height'])
        target = eph[r['body']]
        def residual(seconds):
            moment = t + seconds / 86400.0
            almanac._fastify(moment)
            app = observer.at(moment).observe(target).apparent(())
            if r['kind'] == 'transit':
                return (app.hadec()[0].radians + np.pi) % (2*np.pi) - np.pi
            alt, _, distance = app.altaz()
            h = (almanac.build_horizon_function(target)(distance)
                 if r['horizon'] is None else np.deg2rad(r['horizon']))
            return alt.radians - h
        lo, hi = np.array([-60.0]), np.array([60.0])
        flo, fhi = residual(lo), residual(hi)
        assert (flo * fhi < 0).all(), r
        for _ in range(40):
            mid = (lo + hi) / 2
            fm = residual(mid)
            same = (flo >= 0) == (fm >= 0)
            lo, flo = np.where(same, mid, lo), np.where(same, fm, flo)
            hi = np.where(same, hi, mid)
        error = float(abs((lo + hi)[0] / 2))
        per_dataset[s['_dataset']] = per_dataset.get(s['_dataset'], 0) + 1
        records.append(dict(id=s['id'], dataset=s['_dataset'],
                            latitude=r['lat'], kind=r['kind'], body=r['body'],
                            error_seconds=error))
        if len(records) == 96:
            break
finally:
    eph.close()
report = dict(method=__doc__, events_checked=len(records),
    per_dataset=per_dataset,
    max_error_seconds=max(r['error_seconds'] for r in records), records=records)
(HERE / 'oracle.json').write_text(json.dumps(report, indent=2)+'\n')
print({k:v for k,v in report.items() if k not in ('records', 'method')})
