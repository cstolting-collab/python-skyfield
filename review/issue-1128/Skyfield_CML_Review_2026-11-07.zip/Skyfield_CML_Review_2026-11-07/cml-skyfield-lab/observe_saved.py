"""Turn identical-input Skyfield outputs into explicit, auditable CML state.

The adapter calculates arithmetic predicates. CML's actual bounded invariant
language evaluates those predicates; CML does not perform numerical astronomy.
"""
import json
from pathlib import Path
import sys
import numpy as np
from skyfield import api

HERE = Path(__file__).resolve().parent
ROOT = HERE.parent
TS = api.load.timescale()
WINDOW_TOLERANCE_SECONDS = 1e-6


def observe(record, group, index):
    result = record['result']
    if group == 'cases':
        day = {3: 20, 6: 21, 9: 23, 12: 21}[record['month']]
        start = TS.utc(2026, record['month'], day)
        duration = 2.0
    elif group == 'boundary':
        start = TS.tt_jd(record['start_whole'], record['start_fraction'])
        duration = 1.05
    else:
        start = TS.tt_jd(record['start'])
        duration = 1.05
    state = dict(id=f'{group}-{index}', contract='replay-v1', inputs={k: v for k, v in record.items()
                                               if k != 'result'},
                 status='error' if 'error' in result else 'ok',
                 evidence=result, checks={})
    if 'error' not in result:
        t = TS.tt_jd(np.array(result['whole']), np.array(result['fraction']))
        offsets = (t - start) * 86400.0
        state['offsets_seconds'] = offsets.tolist()
        state['end_offset_seconds'] = duration * 86400.0
        state['checks'] = dict(
            finite=bool(np.isfinite(offsets).all()),
            paired=len(result['whole']) == len(result['flags']),
            ordered=bool((np.diff(offsets) > 0).all()),
            within_window=bool(((offsets >= -WINDOW_TOLERANCE_SECONDS)
                               & (offsets <= duration * 86400.0
                                  + WINDOW_TOLERANCE_SECONDS)).all()),
        )
    return state


if __name__ == '__main__':
    mode = sys.argv[1]
    report = json.loads((ROOT / f'pr1145-probe-{mode}.json').read_text())
    states = [observe(r, key, i) for key in ('cases', 'boundary', 'exact')
              for i, r in enumerate(report[key])]
    (HERE / f'observations-{mode}.json').write_text(
        json.dumps(dict(mode=mode, window_tolerance_seconds=WINDOW_TOLERANCE_SECONDS,
                        states=states), indent=2, allow_nan=False) + '\n')
