import assert from 'node:assert/strict';
import { readFileSync, writeFileSync } from 'node:fs';
import { createHash } from 'node:crypto';
import { compileSource } from 'cml-reference-compiler';
import { StateGovernance } from 'cml-reference-compiler/runtime';

const provenance = JSON.parse(readFileSync(new URL('cml-provenance.json', import.meta.url)));
for (const entry of provenance.files) {
  const bytes = readFileSync(new URL(`node_modules/cml-reference-compiler/${entry.path}`, import.meta.url));
  const hash = createHash('sha1').update(`blob ${bytes.length}\0`).update(bytes).digest('hex');
  assert.equal(hash, entry.git_blob_sha1, entry.path);
}
const source = readFileSync(new URL('node_modules/cml-reference-compiler/examples/natural-smile.cml', import.meta.url), 'utf8');
const compilation = compileSource(source);
assert.equal(compilation.validation.valid, true);

const catalog = JSON.parse(readFileSync(new URL('../catalog-cml-final.json', import.meta.url)));
const invariants = [
  {id: 'completed', assert: {path: 'full_catalog', op: 'equals', value: 'PASS'}},
  {id: 'known_unchanged', assert: {path: 'unchanged_valid_positions', op: 'equals', value: 117955}},
  {id: 'unknowns_preserved', assert: {path: 'nan_rows_preserved', op: 'equals', value: 263}},
  {id: 'scalar_unknowns', assert: {path: 'individual_nan_stars_checked', op: 'equals', value: 263}},
];
const governance = new StateGovernance();
const results = catalog.results.map(candidateState => {
  const result = governance.evaluateTransition({candidateState, invariants});
  assert.equal(result.accepted, true);
  return {observer: candidateState.observer, accepted: result.accepted,
    checked: result.validation.checked};
});
const report = {sourceCommit: provenance.commit,
  sourceFilesVerified: provenance.files.length, compilerExampleValidated: true,
  compilerExampleScope: 'Original language smoke example; numerical checks use the supported runtime API.',
  catalogInvariants: invariants, catalogResults: results};
writeFileSync(new URL('engine-verification.json', import.meta.url), JSON.stringify(report,null,2)+'\n');
console.log(JSON.stringify(report));
