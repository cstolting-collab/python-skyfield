CML + SKYFIELD: MEASURED FOLLOW-UP
7 November 2026

Result

Running the actual CML runtime against explicit numerical requirements led to
one additional Skyfield precision correction beyond the earlier NaN-star and
zero-hour-angle-rate fixes. It resolves 29 additional failing scenarios in this
test set. Those are 29 scenarios, not 29 distinct bugs.

The earlier rate-fixed candidate satisfied 1,391 of 1,420 scenario contracts.
The final candidate satisfies all 1,420 on NumPy 2.3.5 and all the same 1,420 on
NumPy 2.5.3. This is complete coverage of this finite test set, not 100% of
Skyfield's potential, all inputs, or production reliability.

What changed

Skyfield represents time using two floating-point components. The almanac
search still combined those components into a single Julian date while building
its sample grid and interpolating its first guess. This could move a boundary
by microseconds, include an event before the requested start, or miss an event
inside a 20-microsecond interval.

The new patch calculates the interval using Time subtraction, builds samples
as offsets from the original start, and interpolates with Time arithmetic.
It preserves the user's bounds instead of recovering precision after rounding.
One new native regression test covers Sun/Moon rise, set, and transit searches
in containing, preceding, following, and zero-width windows.

The three patches apply in order on karimosama7's PR #1145 head. Credit for the
original split-offset interpolation and initial zero-time guard remains with
that contributor. Patch 01 is our previously tested rate-preservation follow-up.
Patch 02 is the new correction from this CML investigation. Patch 03 is the
previously tested NaN-star propagation and documentation change. No CML runtime
dependency is added to Skyfield; CML is used by the separate review harness.

Public upstream references:
https://github.com/skyfielders/python-skyfield/issues/1128
https://github.com/skyfielders/python-skyfield/pull/1145

What CML actually did

The experiment used CML-Reference-Compiler 1.2.0-alpha.0 at commit
8331c3b1ac6450b12e8a944bd29c629e0f21ae4d. All 76 selected source files were
verified against their Git blob hashes. The original compiler example compiled
and validated, and the original state-governance and adversarial-hardening
test scripts passed. The numerical experiment uses the supported public
cml-reference-compiler/runtime API, specifically StateGovernance and its
invariant and provenance machinery. It is not invented CML source syntax.

The Python adapter computes finite-value, array-pairing, ordering, time-window,
expected-event-count, and crossing-direction observations. CML evaluates the
declared rules and accepts or rejects each candidate. Accepted observations
are committed to a lab in-memory map before provenance is appended. These are
review records, not a durable transaction service or release authorization.

The time-window rule allows 1 microsecond of numerical tolerance. Expected
event counts are asserted only for constructed narrow windows around reference
events, with at least a 10-microsecond margin. For additional searches, true
events must have the requested crossing direction in a +/-60-second bracket.
False high-latitude placeholders are not incorrectly required to cross a
horizon. These rules are explicit test requirements, not universal API proofs.

CML did not invent the numerical correction. The adapter, test cases, rules,
and source-code diagnosis were authored during this investigation. Plain host
logic with exactly the same predicates agreed with all 752 comparison decisions.
CML contributes consistent enforcement and evidence handling; this experiment
does not demonstrate uniquely superior numerical intelligence.

Evidence

                                        Earlier candidate   Final candidate
Original 532 cases                      523 accepted        532 accepted
120 additional tiny-window cases        100 accepted        120 accepted
256 seeded 2026 holdout searches        256 accepted        256 accepted
512 seeded 1905-2045 holdout searches    512 accepted        512 accepted
Total                                  1391 accepted       1420 accepted

Both NumPy versions passed all 1,420 final scenarios. The multi-year holdout
includes polar latitudes, different elevations, eight solar-system targets,
custom horizons, and varied interval lengths. These are deliberately chosen
stress tests and seeded samples, not a representative failure-rate survey.

Across 960 ordinary/holdout cases, event counts and flags were unchanged. The
largest time shift was about 2.001 microseconds. A separate bisection check of
96 returned events (48 from each holdout set) agreed within 1 microsecond. It
uses the same Skyfield ephemeris and apparent-position model, so it independently
checks the root-finding algorithm, not absolute astronomical truth.

The combined final patch also passed the full 118,218-row Hipparcos check from
both Earth-center and surface observers. All 117,955 valid positions remained
byte-identical to filtered upstream results; all 263 unknown rows were retained
and propagated NaN, including scalar checks. CML accepted the two catalog
observation records under explicit preservation rules. Raw NaN cannot be used
as JSON-like CML state; the adapter reports unknown-value behavior explicitly.

Twelve deliberate failures were rejected by CML, including missing required
checks, invalid contract identity, and raw NaN. Rejection preserved the prior
accepted state and appended no accepted provenance. A deliberately dishonest
adapter that reports passing predicates for bad measurements is accepted:
CML trusts supplied observations and cannot infer astronomy from false labels.
That limitation is tested and recorded, rather than hidden.

One local evaluation run averaged about 0.162 ms per CML decision, including a
plain-host comparison. This is an unoptimized single-machine observation, not
an end-to-end speed improvement or a portable performance guarantee.

The final native Skyfield suite passed 591 of 592 tests on NumPy 2.3.5, including
the new regression. The sole failure is the same pre-existing datetime-list
integer/float casting failure observed upstream. Some existing tests also emit
unclosed ephemeris ResourceWarnings. On NumPy 2.5.3, the almanac module passed
15/15 under normal warning settings, and the three relevant almanac regression
functions passed with warnings configured as errors. The entire NumPy 2.5.3
suite was not certified by this experiment.

Why the iteration stops here

After the precision correction, the expanded and second-version runs produced
no further contract failures. The independent root check and injected-failure
controls also passed. There is no remaining reproduced correction from these
checks to justify another code change. Wider platforms, ephemerides, unusual
targets, and long-range integration remain potential future work. A finite
experiment cannot demonstrate that a product has reached its maximum potential.

Review status

The changes, measured evidence, and reproduction scripts are ready for review.
Nothing was pushed, posted, or published during this CML experiment. The package
contains the Skyfield patches and lab harness. CML's repository source remains
in its existing repository; install the pinned compiler separately to rerun.
See REPRODUCE.txt and cml-provenance.json for the exact setup and source identity.
